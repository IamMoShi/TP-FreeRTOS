---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Obtenir la température
 et l'humidité ^kUXjYOxB

Afficher les informations voulues ^vxymvdaX

Obtenir le taux de C02 ^D55EyjX0

Obtenir la distance ^YxoiLUNl

HUMIDITE ^H5xlTSPl

TEMPERATURE ^yNXvA2fm

CO2 ^ccz8ewnP

DISTANCE ^Z9Yor74K

Capteur de CO2 ^TC2r40mg

Capteur de température et d'humidité ^ki6iBnPT

Ecran OLED ^uGMkKjcf

Capteur de distance ^njGuHpQC

Détection et transmission présence ^JApI8pEb

Présence trigger  ^lmXS6kVv

Transmettre CO2 ^5VEhWRqK

CO2t ^cXKYSvs7

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/2.0.25",
	"elements": [
		{
			"type": "ellipse",
			"version": 382,
			"versionNonce": 1932878128,
			"isDeleted": false,
			"id": "r7qxMY6esY502wmas3fs7",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 361.24993896484375,
			"y": -184.63751983642578,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 159.199951171875,
			"height": 151.2000274658203,
			"seed": 1076455581,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "kUXjYOxB"
				},
				{
					"id": "rDb74lq-AntIdhW1phoqb",
					"type": "arrow"
				},
				{
					"id": "g5PwMTSSYwmWd_1WL2KUm",
					"type": "arrow"
				}
			],
			"updated": 1716311145811,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 284,
			"versionNonce": 1815134807,
			"isDeleted": false,
			"id": "kUXjYOxB",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 392.57627121625154,
			"y": -148.99478847185253,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 96.97592163085938,
			"height": 80,
			"seed": 1617983219,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1716321234807,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Obtenir la\ntempérature\net\nl'humidité",
			"rawText": "Obtenir la température\n et l'humidité",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "r7qxMY6esY502wmas3fs7",
			"originalText": "Obtenir la température\n et l'humidité",
			"lineHeight": 1.25,
			"baseline": 74
		},
		{
			"type": "ellipse",
			"version": 440,
			"versionNonce": 307346224,
			"isDeleted": false,
			"id": "snH3qaZ28qMwrAsGoVYXW",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -8.3499755859375,
			"y": -183.0374755859375,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 159.199951171875,
			"height": 151.2000274658203,
			"seed": 1373406419,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "vxymvdaX"
				},
				{
					"id": "BAvCwsnhTlBNBZO1WzLmY",
					"type": "arrow"
				},
				{
					"id": "z-5j9qPBRs1FN3yzpoTL-",
					"type": "arrow"
				},
				{
					"id": "RBhXLDCxEnFpLQwdI3hf5",
					"type": "arrow"
				},
				{
					"id": "V5n5yb28c5AjVeIUOvdlP",
					"type": "arrow"
				},
				{
					"id": "hzb4kRrnBO9likWMqEnak",
					"type": "arrow"
				}
			],
			"updated": 1716311145811,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 380,
			"versionNonce": 478140375,
			"isDeleted": false,
			"id": "vxymvdaX",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 26.823692480899965,
			"y": -137.39474422136425,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 89.28125,
			"height": 60,
			"seed": 1681551987,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1716321234810,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Afficher les\ninformations\nvoulues",
			"rawText": "Afficher les informations voulues",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "snH3qaZ28qMwrAsGoVYXW",
			"originalText": "Afficher les informations voulues",
			"lineHeight": 1.25,
			"baseline": 57
		},
		{
			"type": "ellipse",
			"version": 936,
			"versionNonce": 13817136,
			"isDeleted": false,
			"id": "tshxXXo2LQr44SCmTE1jE",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 544.1300909458821,
			"y": 155.5435503454462,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 159.199951171875,
			"height": 151.2000274658203,
			"seed": 1368992541,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "D55EyjX0"
				},
				{
					"id": "xURUJ5zXMwBFvZJMB6-FY",
					"type": "arrow"
				},
				{
					"id": "yhX-19WV_6QvQfQI-1LJU",
					"type": "arrow"
				}
			],
			"updated": 1716311145811,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 913,
			"versionNonce": 1791693175,
			"isDeleted": false,
			"id": "D55EyjX0",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 585.7684043984617,
			"y": 201.18628171001944,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 76.35195922851562,
			"height": 60,
			"seed": 1994375037,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1716321234812,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Obtenir le\ntaux de\nC02",
			"rawText": "Obtenir le taux de C02",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "tshxXXo2LQr44SCmTE1jE",
			"originalText": "Obtenir le taux de C02",
			"lineHeight": 1.25,
			"baseline": 54
		},
		{
			"type": "ellipse",
			"version": 818,
			"versionNonce": 1948299056,
			"isDeleted": false,
			"id": "2sZSvQdF1DRmWdJp-yHfx",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -167.09950410596986,
			"y": 137.35874462296033,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 159.199951171875,
			"height": 151.2000274658203,
			"seed": 1956278269,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "YxoiLUNl"
				},
				{
					"id": "yGsPrlVJdkNMG-eOHz_if",
					"type": "arrow"
				},
				{
					"id": "8nbo_Q4r3RIyW9-NoNx6o",
					"type": "arrow"
				}
			],
			"updated": 1716311145811,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 844,
			"versionNonce": 1068715063,
			"isDeleted": false,
			"id": "YxoiLUNl",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -122.29692978913238,
			"y": 193.00147598753358,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 70.0234375,
			"height": 40,
			"seed": 925198429,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1716321234813,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Obtenir la\ndistance",
			"rawText": "Obtenir la distance",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "2sZSvQdF1DRmWdJp-yHfx",
			"originalText": "Obtenir la distance",
			"lineHeight": 1.25,
			"baseline": 37
		},
		{
			"type": "text",
			"version": 212,
			"versionNonce": 1393937017,
			"isDeleted": false,
			"id": "H5xlTSPl",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 215.65008544921875,
			"y": -221.6374740600586,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 86.06394958496094,
			"height": 20,
			"seed": 1250325277,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "rDb74lq-AntIdhW1phoqb",
					"type": "arrow"
				},
				{
					"id": "BAvCwsnhTlBNBZO1WzLmY",
					"type": "arrow"
				}
			],
			"updated": 1716321235585,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "HUMIDITE",
			"rawText": "HUMIDITE",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "HUMIDITE",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "line",
			"version": 260,
			"versionNonce": 1358242256,
			"isDeleted": false,
			"id": "BTR0YVTTF6nxGSYBHMqct",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 213.25006103515625,
			"y": -195.83745574951172,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 88.800048828125,
			"height": 1.600006103515625,
			"seed": 420364093,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					88.800048828125,
					-1.600006103515625
				]
			]
		},
		{
			"type": "line",
			"version": 310,
			"versionNonce": 1036165936,
			"isDeleted": false,
			"id": "bnsDVrBZto57c-Mnprwmm",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 214.05010986328125,
			"y": -227.03746795654297,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 87.20001220703125,
			"height": 1.600006103515625,
			"seed": 2061640179,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					87.20001220703125,
					-1.600006103515625
				]
			]
		},
		{
			"type": "text",
			"version": 385,
			"versionNonce": 1776088471,
			"isDeleted": false,
			"id": "yNXvA2fm",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 203.18839604233392,
			"y": -110.34173962092765,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 124.52793884277344,
			"height": 20,
			"seed": 1754702109,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "Q8RF7qf8opoZ1NtH-hj8u",
					"type": "arrow"
				},
				{
					"id": "z-5j9qPBRs1FN3yzpoTL-",
					"type": "arrow"
				}
			],
			"updated": 1716321235585,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "TEMPERATURE",
			"rawText": "TEMPERATURE",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "TEMPERATURE",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "line",
			"version": 451,
			"versionNonce": 1575402800,
			"isDeleted": false,
			"id": "yG4kIsEFzmKT1SYrkkzEq",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 200.78837162827142,
			"y": -84.54172131038078,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 128.800048828125,
			"height": 0.79998779296875,
			"seed": 2059302269,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					128.800048828125,
					-0.79998779296875
				]
			]
		},
		{
			"type": "line",
			"version": 499,
			"versionNonce": 1725099472,
			"isDeleted": false,
			"id": "hfojX8gpRrAAivoKiu-1g",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 201.58842045639642,
			"y": -115.74173351741203,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 124.00006103515625,
			"height": 1.600006103515625,
			"seed": 900513245,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					124.00006103515625,
					-1.600006103515625
				]
			]
		},
		{
			"type": "arrow",
			"version": 80,
			"versionNonce": 1996821239,
			"isDeleted": false,
			"id": "rDb74lq-AntIdhW1phoqb",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 370.85011852937106,
			"y": -155.83492202452942,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 74.734380614332,
			"height": 56.40588027386519,
			"seed": 1510335539,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234805,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "r7qxMY6esY502wmas3fs7",
				"gap": 5.899804477371816,
				"focus": -0.14547949917136588
			},
			"endBinding": {
				"elementId": "H5xlTSPl",
				"gap": 7.5359649658203125,
				"focus": -0.901153934713766
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-74.734380614332,
					-56.40588027386519
				]
			]
		},
		{
			"type": "arrow",
			"version": 44,
			"versionNonce": 534033360,
			"isDeleted": false,
			"id": "Q8RF7qf8opoZ1NtH-hj8u",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 366.050048828125,
			"y": -88.63750457763672,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 36,
			"height": 12.79998779296875,
			"seed": 630169757,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": {
				"elementId": "yNXvA2fm",
				"focus": -0.7487580759231964,
				"gap": 2.333713943017642
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-36,
					-12.79998779296875
				]
			]
		},
		{
			"type": "arrow",
			"version": 112,
			"versionNonce": 386357399,
			"isDeleted": false,
			"id": "BAvCwsnhTlBNBZO1WzLmY",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 210.050048828125,
			"y": -213.12389939532767,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 72.11887617054586,
			"height": 55.54501196211277,
			"seed": 1276168691,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234808,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "H5xlTSPl",
				"gap": 5.60003662109375,
				"focus": 0.8905211791131626
			},
			"endBinding": {
				"elementId": "snH3qaZ28qMwrAsGoVYXW",
				"gap": 5.342172383126709,
				"focus": 0.012488333465772137
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-72.11887617054586,
					55.54501196211277
				]
			]
		},
		{
			"type": "arrow",
			"version": 98,
			"versionNonce": 1029529303,
			"isDeleted": false,
			"id": "z-5j9qPBRs1FN3yzpoTL-",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 200.449951171875,
			"y": -101.39579803876939,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 47.93087027063251,
			"height": 15.520601330923938,
			"seed": 369269235,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234808,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "yNXvA2fm",
				"gap": 2.7384448704589204,
				"focus": -0.6288786138788829
			},
			"endBinding": {
				"elementId": "snH3qaZ28qMwrAsGoVYXW",
				"gap": 2.2778637269387048,
				"focus": -0.44814578071765176
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-47.93087027063251,
					-15.520601330923938
				]
			]
		},
		{
			"type": "text",
			"version": 669,
			"versionNonce": 1724388185,
			"isDeleted": false,
			"id": "ccz8ewnP",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 482.51050339779806,
			"y": 104.98337684358415,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 33.311981201171875,
			"height": 20,
			"seed": 155980029,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "BsGxuGB-LgWPjuBYDGKCN",
					"type": "arrow"
				},
				{
					"id": "xURUJ5zXMwBFvZJMB6-FY",
					"type": "arrow"
				}
			],
			"updated": 1716321235586,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "CO2",
			"rawText": "CO2",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "CO2",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "line",
			"version": 617,
			"versionNonce": 1819672528,
			"isDeleted": false,
			"id": "aNLlneOWvydvC2XzOqj3X",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 479.3102273594394,
			"y": 127.4755690040729,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 40.8001708984375,
			"height": 0.00006103515625,
			"seed": 1727719773,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					40.8001708984375,
					-0.00006103515625
				]
			]
		},
		{
			"type": "line",
			"version": 712,
			"versionNonce": 1036428592,
			"isDeleted": false,
			"id": "1ZuH8WwhrOwak62uNWVHa",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 478.8339964166836,
			"y": 100.27552627946352,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 38.40008544921875,
			"height": 0,
			"seed": 1844426173,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					38.40008544921875,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 682,
			"versionNonce": 196021783,
			"isDeleted": false,
			"id": "xURUJ5zXMwBFvZJMB6-FY",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 570.7512655926155,
			"y": 163.47881296366046,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 48.21923493400527,
			"height": 34.644990201963765,
			"seed": 744748541,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234810,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "tshxXXo2LQr44SCmTE1jE",
				"gap": 8.882181259114603,
				"focus": 0.29898311579845177
			},
			"endBinding": {
				"elementId": "ccz8ewnP",
				"gap": 10.379342754173194,
				"focus": -0.19076022342614032
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-48.21923493400527,
					-34.644990201963765
				]
			]
		},
		{
			"type": "arrow",
			"version": 961,
			"versionNonce": 34235703,
			"isDeleted": false,
			"id": "BsGxuGB-LgWPjuBYDGKCN",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 475.06419811786736,
			"y": 108.73572869723805,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 62.77061952638519,
			"height": 28.39481322957019,
			"seed": 696915,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ccz8ewnP",
				"gap": 7.446305279930698,
				"focus": -0.2405037441922863
			},
			"endBinding": {
				"elementId": "agZ0m9Eg76W9AysNwIx4G",
				"gap": 8.513119554268357,
				"focus": 0.06465047615028334
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-62.77061952638519,
					-28.39481322957019
				]
			]
		},
		{
			"type": "text",
			"version": 767,
			"versionNonce": 1475881655,
			"isDeleted": false,
			"id": "Z9Yor74K",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 36.930440390279955,
			"y": 269.4874330417977,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 85.679931640625,
			"height": 20,
			"seed": 258390909,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "yGsPrlVJdkNMG-eOHz_if",
					"type": "arrow"
				},
				{
					"id": "npYiruUFySk3RV17AeOMn",
					"type": "arrow"
				}
			],
			"updated": 1716321235586,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "DISTANCE",
			"rawText": "DISTANCE",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "DISTANCE",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "line",
			"version": 765,
			"versionNonce": 48437552,
			"isDeleted": false,
			"id": "YThW-uKwY4OUkFCkXpQLN",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 31.761589151548264,
			"y": 296.6718901142005,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 88.800048828125,
			"height": 1.600006103515625,
			"seed": 1499218909,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					88.800048828125,
					-1.600006103515625
				]
			]
		},
		{
			"type": "line",
			"version": 806,
			"versionNonce": 1666863568,
			"isDeleted": false,
			"id": "lMXgFZbHbekIw6Dpu-vEP",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 31.86949464730941,
			"y": 262.0108570510935,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 85.60003662109375,
			"height": 1.600006103515625,
			"seed": 1883357245,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					85.60003662109375,
					-1.600006103515625
				]
			]
		},
		{
			"type": "arrow",
			"version": 613,
			"versionNonce": 1890956375,
			"isDeleted": false,
			"id": "yhX-19WV_6QvQfQI-1LJU",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 742.577984678865,
			"y": 312.06004286779506,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 50.82514722703365,
			"height": 33.333456931694286,
			"seed": 742128115,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234811,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "TC2r40mg",
				"gap": 6.39996337890625,
				"focus": -0.6889827045471775
			},
			"endBinding": {
				"elementId": "tshxXXo2LQr44SCmTE1jE",
				"gap": 4.792868605820459,
				"focus": 0.03233330232309122
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-50.82514722703365,
					-33.333456931694286
				]
			]
		},
		{
			"type": "text",
			"version": 183,
			"versionNonce": 1660829753,
			"isDeleted": false,
			"id": "TC2r40mg",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 748.9779480577713,
			"y": 311.1823536384501,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 129.7919158935547,
			"height": 20,
			"seed": 1751657811,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "yhX-19WV_6QvQfQI-1LJU",
					"type": "arrow"
				}
			],
			"updated": 1716321235587,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Capteur de CO2",
			"rawText": "Capteur de CO2",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Capteur de CO2",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "arrow",
			"version": 71,
			"versionNonce": 976748855,
			"isDeleted": false,
			"id": "g5PwMTSSYwmWd_1WL2KUm",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 589.6500244140625,
			"y": -198.32136518555922,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 76.19289599858166,
			"height": 47.77838100349885,
			"seed": 2066249651,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234805,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "ki6iBnPT",
				"gap": 10.7999267578125,
				"focus": 0.8914243615044076
			},
			"endBinding": {
				"elementId": "r7qxMY6esY502wmas3fs7",
				"gap": 5.073385973196935,
				"focus": 0.04442376688722144
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-76.19289599858166,
					47.77838100349885
				]
			]
		},
		{
			"type": "text",
			"version": 94,
			"versionNonce": 53459927,
			"isDeleted": false,
			"id": "ki6iBnPT",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 600.449951171875,
			"y": -215.43749237060547,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 302.73577880859375,
			"height": 20,
			"seed": 1981874579,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "g5PwMTSSYwmWd_1WL2KUm",
					"type": "arrow"
				}
			],
			"updated": 1716321235587,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Capteur de température et d'humidité",
			"rawText": "Capteur de température et d'humidité",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Capteur de température et d'humidité",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "arrow",
			"version": 66,
			"versionNonce": 974574871,
			"isDeleted": false,
			"id": "RBhXLDCxEnFpLQwdI3hf5",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 15.0499672543929,
			"y": -165.4360916183158,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 79.87534829198702,
			"height": 64.00140075228967,
			"seed": 525472541,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234809,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "snH3qaZ28qMwrAsGoVYXW",
				"gap": 3.2976218096105043,
				"focus": 0.10018708668916115
			},
			"endBinding": {
				"elementId": "uGMkKjcf",
				"gap": 8.800018310546875,
				"focus": 0.20102707110184803
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-79.87534829198702,
					-64.00140075228967
				]
			]
		},
		{
			"type": "text",
			"version": 84,
			"versionNonce": 1436274969,
			"isDeleted": false,
			"id": "uGMkKjcf",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -118.35003662109375,
			"y": -258.23751068115234,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 96.30397033691406,
			"height": 20,
			"seed": 1737270621,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "RBhXLDCxEnFpLQwdI3hf5",
					"type": "arrow"
				}
			],
			"updated": 1716321235588,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Ecran OLED",
			"rawText": "Ecran OLED",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Ecran OLED",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "arrow",
			"version": 1143,
			"versionNonce": 1315987383,
			"isDeleted": false,
			"id": "yGsPrlVJdkNMG-eOHz_if",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -14.311069554272137,
			"y": 258.75448542164725,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 43.303052867061915,
			"height": 17.026473092178662,
			"seed": 180664723,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234812,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "2sZSvQdF1DRmWdJp-yHfx",
				"gap": 7.918577053928388,
				"focus": 0.22533205549614724
			},
			"endBinding": {
				"elementId": "Z9Yor74K",
				"gap": 7.93845707749017,
				"focus": -0.5597951900577958
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					43.303052867061915,
					17.026473092178662
				]
			]
		},
		{
			"type": "arrow",
			"version": 639,
			"versionNonce": 1665605111,
			"isDeleted": false,
			"id": "8nbo_Q4r3RIyW9-NoNx6o",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -221.35737438780686,
			"y": 282.3625259399414,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 57.584796701631234,
			"height": 41.09252842704157,
			"seed": 1823649171,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234813,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "njGuHpQC",
				"gap": 9.20001220703125,
				"focus": -0.36121466448218986
			},
			"endBinding": {
				"elementId": "2sZSvQdF1DRmWdJp-yHfx",
				"gap": 2.2752806315664174,
				"focus": 0.27619282666535133
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					57.584796701631234,
					-41.09252842704157
				]
			]
		},
		{
			"type": "text",
			"version": 222,
			"versionNonce": 1066936567,
			"isDeleted": false,
			"id": "njGuHpQC",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -289.1500244140625,
			"y": 291.56253814697266,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 161.743896484375,
			"height": 20,
			"seed": 267665523,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "8nbo_Q4r3RIyW9-NoNx6o",
					"type": "arrow"
				}
			],
			"updated": 1716321235588,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Capteur de distance",
			"rawText": "Capteur de distance",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Capteur de distance",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "ellipse",
			"version": 1007,
			"versionNonce": 1771909072,
			"isDeleted": false,
			"id": "i6v7pTzy1ZRGReoZk4Dmh",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 116.77713010629043,
			"y": 58.732772669288465,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 159.199951171875,
			"height": 151.2000274658203,
			"seed": 262237939,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "JApI8pEb"
				},
				{
					"id": "npYiruUFySk3RV17AeOMn",
					"type": "arrow"
				},
				{
					"id": "V5n5yb28c5AjVeIUOvdlP",
					"type": "arrow"
				}
			],
			"updated": 1716311145811,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 1144,
			"versionNonce": 459306743,
			"isDeleted": false,
			"id": "JApI8pEb",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 152.3375169231279,
			"y": 104.37550403386173,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 88.5078125,
			"height": 60,
			"seed": 169678995,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1716321234814,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Détection et\ntransmission\nprésence",
			"rawText": "Détection et transmission présence",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "i6v7pTzy1ZRGReoZk4Dmh",
			"originalText": "Détection et transmission présence",
			"lineHeight": 1.25,
			"baseline": 57
		},
		{
			"type": "arrow",
			"version": 1133,
			"versionNonce": 823716471,
			"isDeleted": false,
			"id": "npYiruUFySk3RV17AeOMn",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 107.24169772006526,
			"y": 260.7873575316005,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 40.07949662412129,
			"height": 60.89825803935997,
			"seed": 1868099389,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234813,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "Z9Yor74K",
				"gap": 8.700075510197223,
				"focus": 0.4878959293142498
			},
			"endBinding": {
				"elementId": "i6v7pTzy1ZRGReoZk4Dmh",
				"gap": 4.9089765609046765,
				"focus": 0.06296700046768403
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					40.07949662412129,
					-60.89825803935997
				]
			]
		},
		{
			"type": "arrow",
			"version": 387,
			"versionNonce": 2078013623,
			"isDeleted": false,
			"id": "V5n5yb28c5AjVeIUOvdlP",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 125.19154236937814,
			"y": 94.70025366336588,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 67.38730111434302,
			"height": 124.68758674360639,
			"seed": 1863569651,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234814,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "i6v7pTzy1ZRGReoZk4Dmh",
				"gap": 2.876232600807043,
				"focus": -0.5562107854425259
			},
			"endBinding": {
				"elementId": "snH3qaZ28qMwrAsGoVYXW",
				"gap": 2.899699408824006,
				"focus": 0.6180996515541406
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-67.38730111434302,
					-124.68758674360639
				]
			]
		},
		{
			"type": "text",
			"version": 39,
			"versionNonce": 1142179321,
			"isDeleted": false,
			"id": "lmXS6kVv",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -37.936398079878984,
			"y": 23.8547013416744,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 136.0959014892578,
			"height": 20,
			"seed": 162951741,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1716321235588,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Présence trigger ",
			"rawText": "Présence trigger ",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Présence trigger ",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "ellipse",
			"version": 1002,
			"versionNonce": 944957744,
			"isDeleted": false,
			"id": "agZ0m9Eg76W9AysNwIx4G",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 255.3975475169009,
			"y": -35.63826297546677,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 159.199951171875,
			"height": 151.2000274658203,
			"seed": 134163760,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "5VEhWRqK"
				},
				{
					"id": "BsGxuGB-LgWPjuBYDGKCN",
					"type": "arrow"
				},
				{
					"id": "EoJ0MQ2y6cGO8UQTR7tej",
					"type": "arrow"
				}
			],
			"updated": 1716311145811,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 994,
			"versionNonce": 1096716727,
			"isDeleted": false,
			"id": "5VEhWRqK",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 293.58684058373836,
			"y": 20.00446838910649,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 83.25,
			"height": 40,
			"seed": 67241776,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [],
			"updated": 1716321234815,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "Transmettre\nCO2",
			"rawText": "Transmettre CO2",
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "agZ0m9Eg76W9AysNwIx4G",
			"originalText": "Transmettre CO2",
			"lineHeight": 1.25,
			"baseline": 37
		},
		{
			"type": "text",
			"version": 789,
			"versionNonce": 1790308887,
			"isDeleted": false,
			"id": "cXKYSvs7",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 179.9391360085612,
			"y": -24.18608841082849,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 42.35197448730469,
			"height": 20,
			"seed": 305889072,
			"groupIds": [],
			"frameId": null,
			"roundness": null,
			"boundElements": [
				{
					"id": "EoJ0MQ2y6cGO8UQTR7tej",
					"type": "arrow"
				},
				{
					"id": "hzb4kRrnBO9likWMqEnak",
					"type": "arrow"
				}
			],
			"updated": 1716321235589,
			"link": null,
			"locked": false,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "CO2t",
			"rawText": "CO2t",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "CO2t",
			"lineHeight": 1.25,
			"baseline": 14
		},
		{
			"type": "line",
			"version": 734,
			"versionNonce": 903792592,
			"isDeleted": false,
			"id": "1eKbRK8f9cP3QvpeMTAfL",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 176.73885997020255,
			"y": -1.6938962503397477,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 40.8001708984375,
			"height": 0.00006103515625,
			"seed": 1726224688,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					40.8001708984375,
					-0.00006103515625
				]
			]
		},
		{
			"type": "line",
			"version": 829,
			"versionNonce": 841899312,
			"isDeleted": false,
			"id": "QcAJOoQZ2861XcvIla8xL",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 176.26262902744674,
			"y": -28.893938974949123,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 38.40008544921875,
			"height": 0,
			"seed": 258569008,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716311145811,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					38.40008544921875,
					0
				]
			]
		},
		{
			"type": "arrow",
			"version": 1054,
			"versionNonce": 1497219959,
			"isDeleted": false,
			"id": "EoJ0MQ2y6cGO8UQTR7tej",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 253.41768241226836,
			"y": 0.7820976072814858,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 35.99628427447246,
			"height": 13.62678397050373,
			"seed": 1614718256,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234815,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "agZ0m9Eg76W9AysNwIx4G",
				"gap": 11.691967678151329,
				"focus": 0.06314597330314539
			},
			"endBinding": {
				"elementId": "cXKYSvs7",
				"gap": 1.677574629234698,
				"focus": -0.3618491228783796
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-35.99628427447246,
					-13.62678397050373
				]
			]
		},
		{
			"type": "arrow",
			"version": 1118,
			"versionNonce": 1430524311,
			"isDeleted": false,
			"id": "hzb4kRrnBO9likWMqEnak",
			"fillStyle": "solid",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 169.7089125720246,
			"y": -22.126236647961967,
			"strokeColor": "#1e1e1e",
			"backgroundColor": "transparent",
			"width": 35.912067144503794,
			"height": 30.004615335875442,
			"seed": 522357712,
			"groupIds": [],
			"frameId": null,
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1716321234810,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "cXKYSvs7",
				"gap": 10.230223436536619,
				"focus": -0.6318971917286297
			},
			"endBinding": {
				"elementId": "snH3qaZ28qMwrAsGoVYXW",
				"gap": 5.718541495375987,
				"focus": 0.030276950869651282
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-35.912067144503794,
					-30.004615335875442
				]
			]
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#1e1e1e",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "solid",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 320.1697910853794,
		"scrollY": 294.9561499499226,
		"zoom": {
			"value": 1.75
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"gridColor": {
			"Bold": "#C9C9C9FF",
			"Regular": "#EDEDEDFF"
		},
		"currentStrokeOptions": null,
		"previousGridSize": null,
		"frameRendering": {
			"enabled": true,
			"clip": true,
			"name": true,
			"outline": true
		}
	},
	"files": {}
}
```
%%